# 第三方GMS包使用GMS Express说明
1. 解压第三方GMS包后, 在`partner_gms`目录下, 本地建立git仓库`git init`;
2. 打上附件补丁`partner_gms/partner_gms_adapt_to_GMS_EXPRESS.diff`, 拷贝products下面的mk文件到GMS包的products目录, 并将其中的GMS包版本修改成与当前GMS包版本一致;
3. 补丁打不上的, 有源文件可以参考, 对照补丁自行修改;
4. 不打补丁, 也可以自己对照最新的`GMS Requirements`进行修改.

# 第三方Modules包使用GMS Express说明
1. 解压第三方Modules包后, 在`partner_modules`目录下, 本地建立git仓库`git init`;
2. 打上附件补丁`partner_modules/0001-partner_modules-adapt-to-rockchip-partner_modules.patch`;
3. 补丁打不上的, 有源文件可以参考, 对照补丁自行修改;
